import React, { useState } from "react";
import Course from "./Course"


const Allcourses=()=>{

    const[courses,setCourses]=useState([
        {title:"Java Course",description:"this is demo course"},
        {title:"Django Course",description:"this is demo course"},
        {title:"ReactJs Course",description:"this is demo course"},
        {title:"AngularJs Course",description:"this is demo course"}
    ])

    return(
        <div>
            <h1> All Course</h1>
            <p>List of all courses are as follows</p>

            {
                courses.length>0 ?
                 courses.map((item)=><Course course={item}/>)
                 :"No Courses"
}
        </div>
    );
}
export default Allcourses;